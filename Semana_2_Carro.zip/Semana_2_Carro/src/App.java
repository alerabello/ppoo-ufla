import java.util.Scanner;

// Passo 6 - Evitando atributos e métodos estáticos

public class App {
    public static void main(String[] args) {
        Principal principal = new Principal();
        principal.executar();
    }
}